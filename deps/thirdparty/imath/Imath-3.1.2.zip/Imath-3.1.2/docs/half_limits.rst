half Limits
###########

.. doxygenfile:: half.h
   :sections: define
